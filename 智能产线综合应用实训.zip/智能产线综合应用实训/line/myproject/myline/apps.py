from django.apps import AppConfig


class MylineConfig(AppConfig):
    name = 'myline'
